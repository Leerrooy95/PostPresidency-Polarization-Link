Unwitting Asset Model – Polarization Proof
Generated live: Nov 17 2025

Key finding:
- Obama post-presidency revenue rises with U.S. polarization
- Clinton (control) revenue falls as polarization rises
- Correlation + visual proof in the PNG

Just run: python run_correlations.py
